<?php
header("Content-Type: application/json");

// ===== CONFIGURAÇÃO DA BASE DE DADOS =====
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pap"; // altera se o nome for diferente

// ===== LIGAR À BASE DE DADOS =====
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar ligação
if ($conn->connect_error) {
    die(json_encode(["status" => "erro", "mensagem" => "Falha na ligação: " . $conn->connect_error]));
}

// ===== RECEBER JSON DO ESP32 =====
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["status" => "erro", "mensagem" => "JSON inválido"]);
    exit;
}

// ===== VALIDAR CAMPOS =====
if (
    !isset($data['id_unico_esp32']) ||
    !isset($data['latitude']) ||
    !isset($data['longitude']) ||
    !isset($data['data_hora'])
) {
    echo json_encode(["status" => "erro", "mensagem" => "Campos em falta"]);
    exit;
}

$id = $conn->real_escape_string($data['id_unico_esp32']);
$latitude = floatval($data['latitude']);
$longitude = floatval($data['longitude']);
$data_hora = $conn->real_escape_string($data['data_hora']);

// ===== INSERIR NA BASE DE DADOS =====
$sql = "INSERT INTO localizacoes (id_unico_esp32, latitude, longitude, data_hora)
        VALUES ('$id', '$latitude', '$longitude', '$data_hora')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "sucesso", "mensagem" => "Localização guardada"]);
} else {
    echo json_encode(["status" => "erro", "mensagem" => $conn->error]);
}

$conn->close();
?>