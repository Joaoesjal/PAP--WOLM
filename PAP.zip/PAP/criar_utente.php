<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['cuidador_id'])) {
    header("Location: login.php");
    exit;
}

$cuidador_id = $_SESSION['cuidador_id'];

/* ===================== CRIAR UTENTE + MEDICAMENTOS ===================== */
if (isset($_POST['guardar_dados'])) {

    $nome = $_POST['nome'];
    $data_nascimento = $_POST['data_nascimento'];
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];

    $conn->begin_transaction();

    try {
        // Inserir utente
        $stmt = $conn->prepare("
            INSERT INTO utentes (nome, data_nascimento, peso, altura, id_cuidador)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssdii", $nome, $data_nascimento, $peso, $altura, $cuidador_id);
        $stmt->execute();
        
        $utente_id = $conn->insert_id;

        // Se houver medicamentos guardados na sessão
        if (isset($_SESSION['medicamentos_temp']) && !empty($_SESSION['medicamentos_temp'])) {
            foreach ($_SESSION['medicamentos_temp'] as $medicamento) {
                
                $med_nome = $medicamento['nome'];
                $data_hora_base = $medicamento['data'] . " " . $medicamento['hora'];
                $recorrencia = $medicamento['recorrencia'];
                $num_repeticoes = $medicamento['num_repeticoes'];
                $dias_semana = $medicamento['dias_semana'] ?? [];

                $stmt_med = $conn->prepare("INSERT INTO medicamentos (id_utente, nome, data_hora) VALUES (?, ?, ?)");

                if ($recorrencia === 'unica') {
                    $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_base);
                    $stmt_med->execute();
                } elseif ($recorrencia === 'semanal' && !empty($dias_semana)) {
                    $dateTime = new DateTime($data_hora_base);
                    $contador_tomas = 0;
                    $max_iteracoes = $num_repeticoes * 10;
                    $iteracao = 0;
                    
                    while ($contador_tomas < $num_repeticoes && $iteracao < $max_iteracoes) {
                        $dia_atual = (int)$dateTime->format('w');
                        
                        if (in_array($dia_atual, $dias_semana)) {
                            $data_hora_atual = $dateTime->format('Y-m-d H:i:s');
                            $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_atual);
                            $stmt_med->execute();
                            $contador_tomas++;
                        }
                        
                        $dateTime->modify('+1 day');
                        $iteracao++;
                    }
                } else {
                    $dateTime = new DateTime($data_hora_base);
                    
                    for ($i = 0; $i < $num_repeticoes; $i++) {
                        $data_hora_atual = $dateTime->format('Y-m-d H:i:s');
                        $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_atual);
                        $stmt_med->execute();
                        
                        switch ($recorrencia) {
                            case 'diaria':
                                $dateTime->modify('+1 day');
                                break;
                            case 'mensal':
                                $dateTime->modify('+1 month');
                                break;
                            case 'anual':
                                $dateTime->modify('+1 year');
                                break;
                        }
                    }
                }
            }
        }

        $conn->commit();
        
        // Limpar medicamentos temporários
        unset($_SESSION['medicamentos_temp']);
        
        $_SESSION['mensagem'] = "Utente '$nome' criado com sucesso!";
        header("Location: painel_cuidador.php");
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $erro = "Erro ao criar utente: " . $e->getMessage();
    }
}

/* ===================== ADICIONAR MEDICAMENTO À SESSÃO ===================== */
if (isset($_POST['adicionar_medicamento'])) {

    $nome = $_POST['nome_medicamento'];
    $dose = $_POST['dose'] ?? '';
    $data = $_POST['data'];
    $hora = $_POST['hora'];
    $recorrencia = $_POST['recorrencia'] ?? 'unica';
    $num_repeticoes = isset($_POST['num_repeticoes']) ? intval($_POST['num_repeticoes']) : 1;
    $dias_semana = $_POST['dias_semana'] ?? [];

    // Adicionar dose ao nome se fornecida
    if (!empty($dose)) {
        $nome = $nome . " - " . $dose;
    }

    // Limitar repetições
    if ($num_repeticoes > 365) $num_repeticoes = 365;
    if ($num_repeticoes < 1) $num_repeticoes = 1;

    // Inicializar array se não existir
    if (!isset($_SESSION['medicamentos_temp'])) {
        $_SESSION['medicamentos_temp'] = [];
    }

    // Adicionar medicamento à sessão
    $_SESSION['medicamentos_temp'][] = [
        'nome' => $nome,
        'data' => $data,
        'hora' => $hora,
        'recorrencia' => $recorrencia,
        'num_repeticoes' => $num_repeticoes,
        'dias_semana' => $dias_semana
    ];

    // Recarregar página para mostrar o medicamento adicionado
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

/* ===================== REMOVER MEDICAMENTO DA SESSÃO ===================== */
if (isset($_GET['remover_med'])) {
    $med_index = $_GET['remover_med'];

    if (isset($_SESSION['medicamentos_temp'][$med_index])) {
        unset($_SESSION['medicamentos_temp'][$med_index]);
        $_SESSION['medicamentos_temp'] = array_values($_SESSION['medicamentos_temp']); // Reindexar
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Obter medicamentos temporários
$medicamentos_temp = $_SESSION['medicamentos_temp'] ?? [];
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Criar Utente - WOLM</title>
    <link rel="stylesheet" href="style.css?v=4">
</head>
<body>

<header>
    <h1>WOLM</h1>
</header>

<main class="painel-container">

    <div class="perfil-container">
        <h2>Criar Novo Utente</h2>

        <!-- FORMULÁRIO CRIAR UTENTE -->
        <form method="POST" class="perfil-form">

            <label>Nome</label>
            <input type="text" name="nome" required placeholder="Ex: Maria Silva">

            <label>Data de nascimento</label>
            <input type="date" name="data_nascimento" required>

            <label>Peso (kg)</label>
            <input type="number" step="0.1" name="peso" required placeholder="Ex: 65.5">

            <label>Altura (cm)</label>
            <input type="number" step="0.1" name="altura" required placeholder="Ex: 165">

            <button type="submit" name="guardar_dados" class="btn-verde">
                Guardar alterações do utente
            </button>

        </form>

        <hr style="margin:2rem 0; border: none; height: 2px; background: #e8f5e9;">

        <!-- SEÇÃO MEDICAMENTOS ADICIONADOS -->
        <?php if (!empty($medicamentos_temp)): ?>
        <div class="secao-medicamentos">
            <h3 class="titulo-form">Medicamentos a Adicionar</h3>

            <div class="medicamentos-lista">
                <?php foreach ($medicamentos_temp as $index => $med): ?>
                    <div class="medicamento-card">
                        <div class="medicamento-info">
                            <span class="medicamento-nome"><?= htmlspecialchars($med['nome']) ?></span>
                            <span class="medicamento-data">📅 <?= date("d/m/Y", strtotime($med['data'])) ?> às <?= $med['hora'] ?></span>
                        </div>
                        <a href="?remover_med=<?= $index ?>"
                           onclick="return confirm('Tem a certeza que deseja remover este medicamento?')"
                           class="btn-remover">
                           ❌ Remover
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <hr style="margin:2rem 0; border: none; height: 2px; background: #e8f5e9;">
        <?php endif; ?>

        <!-- SEÇÃO ADICIONAR MEDICAMENTO -->
        <div class="secao-adicionar">
            <h3 class="titulo-form">➕ Adicionar Novo Medicamento</h3>

            <button type="button" class="btn-verde" onclick="toggleMedicamentoForm()">
                ➕ Adicionar medicamento
            </button>

            <div id="formMedicamento" class="form-medicamento-wrapper" style="display:none;">
                <form method="POST" class="perfil-form">

                    <label>Nome do medicamento</label>
                    <input type="text" name="nome_medicamento" required placeholder="Ex: Paracetamol">

                    <label>Dose</label>
                    <input type="text" name="dose" placeholder="Ex: 500mg, 1 comprimido, 2ml...">

                    <div class="form-row">
                        <div class="form-col">
                            <label>Data de início</label>
                            <input type="date" name="data" required>
                        </div>
                        <div class="form-col">
                            <label>Hora</label>
                            <input type="time" name="hora" required>
                        </div>
                    </div>

                    <label>Recorrência</label>
                    <select name="recorrencia" id="recorrencia" onchange="toggleRecorrencia()" class="select-recorrencia">
                        <option value="unica">Toma única</option>
                        <option value="diaria">Diária (todos os dias)</option>
                        <option value="semanal">Semanal (todas as semanas)</option>
                        <option value="mensal">Mensal (todos os meses)</option>
                        <option value="anual">Anual (todos os anos)</option>
                    </select>

                    <div id="opcoes-recorrencia" style="display:none;">
                        <div class="info-recorrencia">
                            <p><strong>Como funciona:</strong></p>
                            <ul id="exemplo-recorrencia">
                                <!-- Preenchido via JavaScript -->
                            </ul>
                        </div>
                        
                        <label>Quantas vezes tomar?</label>
                        <input type="number" name="num_repeticoes" id="num_repeticoes" min="1" max="365" value="30" placeholder="Ex: 30" onchange="atualizarExemplo()">
                        
                        <div class="form-col" id="dia-semana-wrapper" style="display:none; margin-top:1rem;">
                            <label>Escolher dias da semana</label>
                            <div class="dias-semana-checkboxes">
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="1" onchange="atualizarExemplo()">
                                    <span>Seg</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="2" onchange="atualizarExemplo()">
                                    <span>Ter</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="3" onchange="atualizarExemplo()">
                                    <span>Qua</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="4" onchange="atualizarExemplo()">
                                    <span>Qui</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="5" onchange="atualizarExemplo()">
                                    <span>Sex</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="6" onchange="atualizarExemplo()">
                                    <span>Sáb</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" name="dias_semana[]" value="0" onchange="atualizarExemplo()">
                                    <span>Dom</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="adicionar_medicamento" class="btn-verde">
                        Guardar medicamento
                    </button>

                </form>
            </div>
        </div>

        <br>
        <a href="painel_cuidador.php" class="botao outline">⬅ Voltar ao painel</a>
    </div>

</main>

<script>
function toggleMedicamentoForm() {
    const form = document.getElementById('formMedicamento');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function toggleRecorrencia() {
    const recorrencia = document.getElementById('recorrencia').value;
    const opcoesDiv = document.getElementById('opcoes-recorrencia');
    const diaSemanaWrapper = document.getElementById('dia-semana-wrapper');
    
    if (recorrencia === 'unica') {
        opcoesDiv.style.display = 'none';
        diaSemanaWrapper.style.display = 'none';
    } else {
        opcoesDiv.style.display = 'block';
        
        if (recorrencia === 'semanal') {
            diaSemanaWrapper.style.display = 'block';
        } else {
            diaSemanaWrapper.style.display = 'none';
        }
        
        atualizarExemplo();
    }
}

function atualizarExemplo() {
    const recorrencia = document.getElementById('recorrencia').value;
    const numRepeticoes = document.getElementById('num_repeticoes').value || 30;
    const exemploDiv = document.getElementById('exemplo-recorrencia');
    
    const diasSelecionados = Array.from(document.querySelectorAll('input[name="dias_semana[]"]:checked'))
        .map(cb => cb.nextElementSibling.textContent);
    
    let exemplos = [];
    
    switch(recorrencia) {
        case 'diaria':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por dia)`,
                `Exemplo: se começar hoje, terá medicamentos até daqui a ${numRepeticoes} dias`
            ];
            break;
        case 'semanal':
            if (diasSelecionados.length > 0) {
                const diasTexto = diasSelecionados.join(', ');
                exemplos = [
                    `Vai criar <strong>${numRepeticoes} tomas</strong>`,
                    `Dias: <strong>${diasTexto}</strong>`,
                    `Exemplo: ${numRepeticoes} tomas distribuídas pelos dias escolhidos`
                ];
            } else {
                exemplos = [
                    "Pode escolher mais do que um dia da semana"
                ];
            }
            break;
        case 'mensal':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por mês)`,
                `Sempre no mesmo dia do mês`,
                `Duração: ${numRepeticoes} meses`
            ];
            break;
        case 'anual':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por ano)`,
                `Sempre no mesmo dia e mês`,
                `Duração: ${numRepeticoes} anos`
            ];
            break;
    }
    
    if (exemplos.length > 0) {
        exemploDiv.innerHTML = exemplos.map(ex => `<li>${ex}</li>`).join('');
    }
}
</script>

<footer>
    <p>&copy; 2025 WOLM</p>
</footer>

</body>
</html>