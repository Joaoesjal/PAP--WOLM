<?php
session_start();

// Verificar se está logado
if (!isset($_SESSION['cuidador_id'])) {
    header("Location: login.php");
    exit;
}

require_once 'db_connection.php';

$cuidador_id = $_SESSION['cuidador_id'];

// Verificar se foi passado um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['erro'] = "ID do utente não fornecido.";
    header("Location: painel_cuidador.php");
    exit;
}

$utente_id = (int)$_GET['id'];

// Verificar se o utente pertence ao cuidador
$stmt = $conn->prepare("SELECT nome FROM utentes WHERE id = ? AND id_cuidador = ?");
$stmt->bind_param("ii", $utente_id, $cuidador_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['erro'] = "Utente não encontrado ou não pertence a você.";
    header("Location: painel_cuidador.php");
    exit;
}

$utente = $result->fetch_assoc();
$nome_utente = $utente['nome'];

// Remover medicamentos associados ao utente
$stmt = $conn->prepare("DELETE FROM medicamentos WHERE id_utente = ?");
$stmt->bind_param("i", $utente_id);
$stmt->execute();

// Remover o utente
$stmt = $conn->prepare("DELETE FROM utentes WHERE id = ? AND id_cuidador = ?");
$stmt->bind_param("ii", $utente_id, $cuidador_id);

if ($stmt->execute()) {
    $_SESSION['mensagem'] = "Utente '$nome_utente' removido com sucesso!";
} else {
    $_SESSION['erro'] = "Erro ao remover utente. Tente novamente.";
}

$stmt->close();
$conn->close();

header("Location: painel_cuidador.php");
exit;
?>