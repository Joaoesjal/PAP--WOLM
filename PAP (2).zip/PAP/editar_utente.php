<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['cuidador_id'])) {
    header("Location: login.php");
    exit;
}

$cuidador_id = $_SESSION['cuidador_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nome = $_POST['nome'];
    $data_nascimento = $_POST['data_nascimento'];
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];

    // Iniciar transação
    $conn->begin_transaction();

    try {
        // Inserir utente
        $stmt = $conn->prepare("
            INSERT INTO utentes (nome, data_nascimento, peso, altura, id_cuidador)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssdii", $nome, $data_nascimento, $peso, $altura, $cuidador_id);
        $stmt->execute();
        
        // Pegar o ID do utente criado
        $utente_id = $conn->insert_id;

        // Se houver medicamentos para adicionar
        if (isset($_POST['medicamentos']) && is_array($_POST['medicamentos'])) {
            foreach ($_POST['medicamentos'] as $medicamento) {
                if (!empty($medicamento['nome_medicamento'])) {
                    $med_nome = $medicamento['nome_medicamento'];
                    $med_dose = $medicamento['dose'] ?? '';
                    $data = $medicamento['data'];
                    $hora = $medicamento['hora'];
                    $recorrencia = $medicamento['recorrencia'] ?? 'unica';
                    $num_repeticoes = isset($medicamento['num_repeticoes']) ? intval($medicamento['num_repeticoes']) : 1;
                    $dias_semana = $medicamento['dias_semana'] ?? [];

                    // Adicionar dose ao nome se fornecida
                    if (!empty($med_dose)) {
                        $med_nome = $med_nome . " - " . $med_dose;
                    }

                    // Limitar repetições
                    if ($num_repeticoes > 365) $num_repeticoes = 365;
                    if ($num_repeticoes < 1) $num_repeticoes = 1;

                    $data_hora_base = $data . " " . $hora;
                    
                    $stmt_med = $conn->prepare("INSERT INTO medicamentos (id_utente, nome, data_hora) VALUES (?, ?, ?)");

                    if ($recorrencia === 'unica') {
                        // Apenas uma toma
                        $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_base);
                        $stmt_med->execute();
                    } elseif ($recorrencia === 'semanal' && !empty($dias_semana)) {
                        // Recorrência semanal com dias específicos
                        $dateTime = new DateTime($data_hora_base);
                        $contador_tomas = 0;
                        $max_iteracoes = $num_repeticoes * 10;
                        $iteracao = 0;
                        
                        while ($contador_tomas < $num_repeticoes && $iteracao < $max_iteracoes) {
                            $dia_atual = (int)$dateTime->format('w');
                            
                            if (in_array($dia_atual, $dias_semana)) {
                                $data_hora_atual = $dateTime->format('Y-m-d H:i:s');
                                $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_atual);
                                $stmt_med->execute();
                                $contador_tomas++;
                            }
                            
                            $dateTime->modify('+1 day');
                            $iteracao++;
                        }
                    } else {
                        // Outras recorrências (diária, mensal, anual)
                        $dateTime = new DateTime($data_hora_base);
                        
                        for ($i = 0; $i < $num_repeticoes; $i++) {
                            $data_hora_atual = $dateTime->format('Y-m-d H:i:s');
                            
                            $stmt_med->bind_param("iss", $utente_id, $med_nome, $data_hora_atual);
                            $stmt_med->execute();
                            
                            switch ($recorrencia) {
                                case 'diaria':
                                    $dateTime->modify('+1 day');
                                    break;
                                case 'mensal':
                                    $dateTime->modify('+1 month');
                                    break;
                                case 'anual':
                                    $dateTime->modify('+1 year');
                                    break;
                            }
                        }
                    }
                }
            }
        }

        // Confirmar transação
        $conn->commit();
        
        $_SESSION['mensagem'] = "Utente '$nome' criado com sucesso!";
        header("Location: painel_cuidador.php");
        exit;

    } catch (Exception $e) {
        // Reverter em caso de erro
        $conn->rollback();
        $erro = "Erro ao criar utente: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Criar Utente - WOLM</title>
    <link rel="stylesheet" href="style.css?v=4">
</head>
<body>

<header>
    <h1>WOLM</h1>
</header>

<main class="painel-container">

    <div class="perfil-container">
        <h2>Criar Novo Utente</h2>

        <?php if (!empty($erro)): ?>
            <div class="perfil-erro">✗ <?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <!-- FORMULÁRIO CRIAR UTENTE -->
        <form method="POST" class="perfil-form" id="formCriarUtente">

            <label>Nome</label>
            <input type="text" name="nome" required placeholder="Ex: Maria Silva">

            <label>Data de nascimento</label>
            <input type="date" name="data_nascimento" required>

            <label>Peso (kg)</label>
            <input type="number" step="0.1" name="peso" required placeholder="Ex: 65.5">

            <label>Altura (cm)</label>
            <input type="number" step="0.1" name="altura" required placeholder="Ex: 165">

            <button type="submit" class="btn-verde">
                Guardar alterações do utente
            </button>

        </form>

        <hr style="margin:2rem 0; border: none; height: 2px; background: #e8f5e9;">

        <!-- SEÇÃO ADICIONAR MEDICAMENTO -->
        <div class="secao-adicionar">
            <h3 class="titulo-form">➕ Adicionar Novo Medicamento</h3>

            <button type="button" class="btn-verde" onclick="toggleMedicamentoForm()">
                ➕ Adicionar medicamento
            </button>

            <div id="formMedicamento" class="form-medicamento-wrapper" style="display:none;">
                <!-- Este form será preenchido dinamicamente -->
                <form class="perfil-form" id="formMedicamentoTemp">

                    <label>Nome do medicamento</label>
                    <input type="text" id="nome_medicamento_temp" required placeholder="Ex: Paracetamol">

                    <label>Dose</label>
                    <input type="text" id="dose_temp" placeholder="Ex: 500mg, 1 comprimido, 2ml...">

                    <div class="form-row">
                        <div class="form-col">
                            <label>Data de início</label>
                            <input type="date" id="data_temp" required>
                        </div>
                        <div class="form-col">
                            <label>Hora</label>
                            <input type="time" id="hora_temp" required>
                        </div>
                    </div>

                    <label>Recorrência</label>
                    <select id="recorrencia_temp" onchange="toggleRecorrencia()" class="select-recorrencia">
                        <option value="unica">Toma única</option>
                        <option value="diaria">Diária (todos os dias)</option>
                        <option value="semanal">Semanal (todas as semanas)</option>
                        <option value="mensal">Mensal (todos os meses)</option>
                        <option value="anual">Anual (todos os anos)</option>
                    </select>

                    <div id="opcoes-recorrencia" style="display:none;">
                        <div class="info-recorrencia">
                            <p><strong>Como funciona:</strong></p>
                            <ul id="exemplo-recorrencia">
                                <!-- Preenchido via JavaScript -->
                            </ul>
                        </div>
                        
                        <label>Quantas vezes tomar?</label>
                        <input type="number" id="num_repeticoes_temp" min="1" max="365" value="30" placeholder="Ex: 30" onchange="atualizarExemplo()">
                        
                        <div class="form-col" id="dia-semana-wrapper" style="display:none; margin-top:1rem;">
                            <label>Escolher dias da semana</label>
                            <div class="dias-semana-checkboxes">
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="1" onchange="atualizarExemplo()">
                                    <span>Seg</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="2" onchange="atualizarExemplo()">
                                    <span>Ter</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="3" onchange="atualizarExemplo()">
                                    <span>Qua</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="4" onchange="atualizarExemplo()">
                                    <span>Qui</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="5" onchange="atualizarExemplo()">
                                    <span>Sex</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="6" onchange="atualizarExemplo()">
                                    <span>Sáb</span>
                                </label>
                                <label class="checkbox-dia">
                                    <input type="checkbox" class="dia_semana_temp" value="0" onchange="atualizarExemplo()">
                                    <span>Dom</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <button type="button" onclick="guardarMedicamento()" class="btn-verde">
                        Guardar medicamento
                    </button>

                </form>
            </div>

            <!-- Lista de medicamentos adicionados -->
            <div id="medicamentos-adicionados" style="margin-top: 1.5rem;">
                <!-- Medicamentos aparecerão aqui -->
            </div>

        </div>

        <br>
        <a href="painel_cuidador.php" class="botao outline">⬅ Voltar ao painel</a>
    </div>

</main>

<script>
let medicamentosLista = [];
let contadorMedicamentos = 0;

function toggleMedicamentoForm() {
    const form = document.getElementById('formMedicamento');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function toggleRecorrencia() {
    const recorrencia = document.getElementById('recorrencia_temp').value;
    const opcoesDiv = document.getElementById('opcoes-recorrencia');
    const diaSemanaWrapper = document.getElementById('dia-semana-wrapper');
    
    if (recorrencia === 'unica') {
        opcoesDiv.style.display = 'none';
        diaSemanaWrapper.style.display = 'none';
    } else {
        opcoesDiv.style.display = 'block';
        
        if (recorrencia === 'semanal') {
            diaSemanaWrapper.style.display = 'block';
        } else {
            diaSemanaWrapper.style.display = 'none';
        }
        
        atualizarExemplo();
    }
}

function atualizarExemplo() {
    const recorrencia = document.getElementById('recorrencia_temp').value;
    const numRepeticoes = document.getElementById('num_repeticoes_temp').value || 30;
    const exemploDiv = document.getElementById('exemplo-recorrencia');
    
    const diasSelecionados = Array.from(document.querySelectorAll('.dia_semana_temp:checked'))
        .map(cb => cb.nextElementSibling.textContent);
    
    let exemplos = [];
    
    switch(recorrencia) {
        case 'diaria':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por dia)`,
                `Exemplo: se começar hoje, terá medicamentos até daqui a ${numRepeticoes} dias`
            ];
            break;
        case 'semanal':
            if (diasSelecionados.length > 0) {
                const diasTexto = diasSelecionados.join(', ');
                exemplos = [
                    `Vai criar <strong>${numRepeticoes} tomas</strong>`,
                    `Dias: <strong>${diasTexto}</strong>`,
                    `Exemplo: ${numRepeticoes} tomas distribuídas pelos dias escolhidos`
                ];
            } else {
                exemplos = [
                    "⚠️ Escolha pelo menos um dia da semana"
                ];
            }
            break;
        case 'mensal':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por mês)`,
                `Sempre no mesmo dia do mês`,
                `Duração: ${numRepeticoes} meses`
            ];
            break;
        case 'anual':
            exemplos = [
                `Vai criar <strong>${numRepeticoes} tomas</strong> (uma por ano)`,
                `Sempre no mesmo dia e mês`,
                `Duração: ${numRepeticoes} anos`
            ];
            break;
    }
    
    if (exemplos.length > 0) {
        exemploDiv.innerHTML = exemplos.map(ex => `<li>${ex}</li>`).join('');
    }
}

function guardarMedicamento() {
    // Pegar valores do formulário temporário
    const nome = document.getElementById('nome_medicamento_temp').value;
    const dose = document.getElementById('dose_temp').value;
    const data = document.getElementById('data_temp').value;
    const hora = document.getElementById('hora_temp').value;
    const recorrencia = document.getElementById('recorrencia_temp').value;
    const num_repeticoes = document.getElementById('num_repeticoes_temp').value;
    
    const dias_semana = Array.from(document.querySelectorAll('.dia_semana_temp:checked'))
        .map(cb => cb.value);
    
    if (!nome || !data || !hora) {
        alert('Por favor, preencha todos os campos obrigatórios!');
        return;
    }
    
    contadorMedicamentos++;
    
    // Adicionar à lista
    medicamentosLista.push({
        id: contadorMedicamentos,
        nome: nome,
        dose: dose,
        data: data,
        hora: hora,
        recorrencia: recorrencia,
        num_repeticoes: num_repeticoes,
        dias_semana: dias_semana
    });
    
    // Adicionar inputs hidden ao formulário principal
    adicionarInputsHidden(contadorMedicamentos, nome, dose, data, hora, recorrencia, num_repeticoes, dias_semana);
    
    // Mostrar na lista
    mostrarMedicamentosAdicionados();
    
    // Limpar formulário temporário
    document.getElementById('formMedicamentoTemp').reset();
    document.getElementById('opcoes-recorrencia').style.display = 'none';
    document.getElementById('dia-semana-wrapper').style.display = 'none';
    
    // Esconder formulário
    document.getElementById('formMedicamento').style.display = 'none';
    
    alert('✅ Medicamento adicionado! Clique em "Guardar alterações do utente" para salvar tudo.');
}

function adicionarInputsHidden(id, nome, dose, data, hora, recorrencia, num_repeticoes, dias_semana) {
    const form = document.getElementById('formCriarUtente');
    
    const inputNome = document.createElement('input');
    inputNome.type = 'hidden';
    inputNome.name = `medicamentos[${id}][nome_medicamento]`;
    inputNome.value = nome;
    inputNome.id = `med_nome_${id}`;
    form.appendChild(inputNome);
    
    const inputDose = document.createElement('input');
    inputDose.type = 'hidden';
    inputDose.name = `medicamentos[${id}][dose]`;
    inputDose.value = dose;
    inputDose.id = `med_dose_${id}`;
    form.appendChild(inputDose);
    
    const inputData = document.createElement('input');
    inputData.type = 'hidden';
    inputData.name = `medicamentos[${id}][data]`;
    inputData.value = data;
    inputData.id = `med_data_${id}`;
    form.appendChild(inputData);
    
    const inputHora = document.createElement('input');
    inputHora.type = 'hidden';
    inputHora.name = `medicamentos[${id}][hora]`;
    inputHora.value = hora;
    inputHora.id = `med_hora_${id}`;
    form.appendChild(inputHora);
    
    const inputRecorrencia = document.createElement('input');
    inputRecorrencia.type = 'hidden';
    inputRecorrencia.name = `medicamentos[${id}][recorrencia]`;
    inputRecorrencia.value = recorrencia;
    inputRecorrencia.id = `med_recorrencia_${id}`;
    form.appendChild(inputRecorrencia);
    
    const inputRepeticoes = document.createElement('input');
    inputRepeticoes.type = 'hidden';
    inputRepeticoes.name = `medicamentos[${id}][num_repeticoes]`;
    inputRepeticoes.value = num_repeticoes;
    inputRepeticoes.id = `med_repeticoes_${id}`;
    form.appendChild(inputRepeticoes);
    
    // Dias da semana
    dias_semana.forEach(dia => {
        const inputDia = document.createElement('input');
        inputDia.type = 'hidden';
        inputDia.name = `medicamentos[${id}][dias_semana][]`;
        inputDia.value = dia;
        inputDia.className = `med_dia_${id}`;
        form.appendChild(inputDia);
    });
}

function mostrarMedicamentosAdicionados() {
    const container = document.getElementById('medicamentos-adicionados');
    
    if (medicamentosLista.length === 0) {
        container.innerHTML = '';
        return;
    }
    
    let html = '<h4 style="color: #1b5e20; margin-top: 2rem;">Medicamentos a adicionar:</h4>';
    html += '<div class="medicamentos-lista">';
    
    medicamentosLista.forEach(med => {
        const nomeCompleto = med.dose ? `${med.nome} - ${med.dose}` : med.nome;
        html += `
            <div class="medicamento-card">
                <div class="medicamento-info">
                    <span class="medicamento-nome">${nomeCompleto}</span>
                    <span class="medicamento-data">${formatarData(med.data)} às ${med.hora} - ${formatarRecorrencia(med.recorrencia)}</span>
                </div>
                <button type="button" onclick="removerMedicamento(${med.id})" class="btn-remover">
                    ❌ Remover
                </button>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

function removerMedicamento(id) {
    if (!confirm('Tem a certeza que deseja remover este medicamento?')) {
        return;
    }
    
    // Remover da lista
    medicamentosLista = medicamentosLista.filter(med => med.id !== id);
    
    // Remover inputs hidden
    document.getElementById(`med_nome_${id}`)?.remove();
    document.getElementById(`med_dose_${id}`)?.remove();
    document.getElementById(`med_data_${id}`)?.remove();
    document.getElementById(`med_hora_${id}`)?.remove();
    document.getElementById(`med_recorrencia_${id}`)?.remove();
    document.getElementById(`med_repeticoes_${id}`)?.remove();
    
    // Remover dias da semana
    document.querySelectorAll(`.med_dia_${id}`).forEach(el => el.remove());
    
    // Atualizar visualização
    mostrarMedicamentosAdicionados();
}

function formatarData(data) {
    const partes = data.split('-');
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
}

function formatarRecorrencia(rec) {
    const nomes = {
        'unica': 'Toma única',
        'diaria': 'Diária',
        'semanal': 'Semanal',
        'mensal': 'Mensal',
        'anual': 'Anual'
    };
    return nomes[rec] || rec;
}
</script>

<footer>
    <p>&copy; 2025 WOLM</p>
</footer>

</body>
</html>